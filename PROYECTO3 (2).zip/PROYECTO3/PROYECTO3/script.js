// 1. Base de datos con tus canciones e imágenes asignadas
const canciones = [
    {
        titulo: "Naturaleza",
        artista: "anuel",
        url: "audio/naturaleza.mp3",
        portada:"asset/img/naturaleza.JPG"
    },
    {
        titulo: "Ayer 2",
        artista: "Anuel AA ft. Varios",
        url: "audio/ayer2.mp3",
        portada: "img/ayer2.jpg"
    },
    {
        titulo: "Culpables",
        artista: "Anuel AA, Karol G",
        url: "audio/culpables.mp3",
        portada: "img/culpables.jpg"
    },
    {
        titulo: "Anuel Pista",
        artista: "Anuel AA",
        url: "audio/anuel_pista.mp3",
        portada: "img/anuel.jpg"
    }
];

let indiceActual = 0;
let estaReproduciendo = false;
const audio = new Audio();

// Selección de elementos del DOM
const tituloActual = document.getElementById('current-title');
const artistaActual = document.getElementById('current-artist');
const imagenPortada = document.getElementById('current-cover');
const btnPlayPause = document.getElementById('btn-play-pause');
const iconoPlay = document.getElementById('play-icon');
const btnPrev = document.getElementById('btn-prev');
const btnNext = document.getElementById('btn-next');
const barraProgreso = document.querySelector('.progress-bar');
const contenedorProgreso = document.querySelector('.progress-container');
const itemsLista = document.querySelectorAll('.track-item');

// Función para cargar canción e imagen
function cargarCancion(indice) {
    indiceActual = indice;
    const cancion = canciones[indiceActual];
    
    audio.src = cancion.url;
    tituloActual.textContent = cancion.titulo;
    artistaActual.textContent = cancion.artista;
    imagenPortada.src = cancion.portada; 
    
    actualizarListaVisual();
}

function reproducirCancion() {
    estaReproduciendo = true;
    iconoPlay.textContent = 'pause';
    audio.play();
}

function pausarCancion() {
    estaReproduciendo = false;
    iconoPlay.textContent = 'play_arrow';
    audio.pause();
}

function cancionAnterior() {
    indiceActual--;
    if (indiceActual < 0) indiceActual = canciones.length - 1;
    cargarCancion(indiceActual);
    if (estaReproduciendo) audio.play();
}

function cancionSiguiente() {
    indiceActual++;
    if (indiceActual >= canciones.length) indiceActual = 0;
    cargarCancion(indiceActual);
    if (estaReproduciendo) audio.play();
}

function actualizarListaVisual() {
    itemsLista.forEach((item, index) => {
        if (index === indiceActual) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });
}

function actualizarProgreso(e) {
    const { duration, currentTime } = e.srcElement;
    if (duration) {
        const porcentaje = (currentTime / duration) * 100;
        barraProgreso.style.width = `${porcentaje}%`;
    }
}

function cambiarProgresoManual(e) {
    const anchoContenedor = this.clientWidth;
    const clickX = e.offsetX;
    const duracionTotal = audio.duration;
    if (duracionTotal) {
        audio.currentTime = (clickX / anchoContenedor) * duracionTotal;
    }
}

// Event Listeners
btnPlayPause.addEventListener('click', () => {
    if (estaReproduciendo) { pausarCancion(); } else { reproducirCancion(); }
});

btnPrev.addEventListener('click', cancionAnterior);
btnNext.addEventListener('click', cancionSiguiente);
audio.addEventListener('timeupdate', actualizarProgreso);
audio.addEventListener('ended', cancionSiguiente);
contenedorProgreso.addEventListener('click', cambiarProgresoManual);

itemsLista.forEach(item => {
    item.addEventListener('click', () => {
        const index = parseInt(item.getAttribute('data-index'));
        cargarCancion(index);
        reproducirCancion();
    });
});

// Inicializar
cargarCancion(indiceActual);